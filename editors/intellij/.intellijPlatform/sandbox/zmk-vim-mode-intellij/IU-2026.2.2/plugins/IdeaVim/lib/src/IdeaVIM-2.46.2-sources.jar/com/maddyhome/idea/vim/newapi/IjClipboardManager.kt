/*
 * Copyright 2003-2026 The IdeaVim authors
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE.txt file or at
 * https://opensource.org/licenses/MIT.
 */

package com.maddyhome.idea.vim.newapi

import com.intellij.codeInsight.editorActions.CopyPastePostProcessor
import com.intellij.codeInsight.editorActions.CopyPastePreProcessor
import com.intellij.codeInsight.editorActions.TextBlockTransferable
import com.intellij.codeInsight.editorActions.TextBlockTransferableData
import com.intellij.ide.CopyPasteManagerEx
import com.intellij.openapi.editor.CaretStateTransferableData
import com.intellij.openapi.editor.RawText
import com.intellij.openapi.editor.richcopy.view.HtmlTransferableData
import com.intellij.openapi.editor.richcopy.view.RtfTransferableData
import com.intellij.openapi.Disposable
import com.intellij.openapi.project.DumbService
import com.intellij.openapi.project.IndexNotReadyException
import com.intellij.psi.PsiDocumentManager
import com.maddyhome.idea.vim.api.ExecutionContext
import com.maddyhome.idea.vim.api.ImmutableVimCaret
import com.maddyhome.idea.vim.api.OwnedPrimaryContent
import com.maddyhome.idea.vim.api.VimClipboardManager
import com.maddyhome.idea.vim.api.VimEditor
import com.maddyhome.idea.vim.api.injector
import com.maddyhome.idea.vim.command.Command
import com.maddyhome.idea.vim.common.TextRange
import com.maddyhome.idea.vim.common.VimCopiedText
import com.maddyhome.idea.vim.diagnostic.debug
import com.maddyhome.idea.vim.diagnostic.vimLogger
import com.maddyhome.idea.vim.state.mode.SelectionType
import com.maddyhome.idea.vim.state.mode.inVisualMode
import com.maddyhome.idea.vim.state.mode.selectionType
import java.awt.HeadlessException
import java.awt.Toolkit
import java.awt.datatransfer.DataFlavor
import java.awt.datatransfer.Transferable
import java.awt.datatransfer.UnsupportedFlavorException
import java.io.IOException
import java.util.concurrent.atomic.AtomicReference


// Disposable so the PRIMARY writer's background thread and helper process are released when the
// service goes away. That covers plugin unload as well as shutdown: IdeaVim's extension points are
// all dynamic, so an un-disposed executor would pin the plugin classloader across a reload.
internal class IjClipboardManager : VimClipboardManager, Disposable {
  private val primaryWriter: PrimarySelectionWriter = primarySelectionWriter()
  private val publishedToPrimary = AtomicReference<OwnedPrimaryContent?>()

  override fun dispose() {
    primaryWriter.dispose()
    publishedToPrimary.set(null)
  }

  override fun getPrimaryContent(editor: VimEditor, context: ExecutionContext): IjVimCopiedText? {
    val clipboard = Toolkit.getDefaultToolkit()?.systemSelection ?: return null
    val contents = clipboard.getContents(null) ?: return null
    val (text, transferableData) = getTextAndTransferableData(contents) ?: return null
    return IjVimCopiedText(text, transferableData ?: emptyList())
  }

  override fun getClipboardContent(editor: VimEditor, context: ExecutionContext): VimCopiedText? {
    val contents = getContents() ?: return null
    val (text, transferableData) = getTextAndTransferableData(contents) ?: return null
    return IjVimCopiedText(text, transferableData ?: emptyList())
  }

  override fun setClipboardContent(editor: VimEditor, context: ExecutionContext, textData: VimCopiedText): Boolean {
    require(textData is IjVimCopiedText)
    return handleTextSetting(
      textData.text,
      textData.text,
      textData.transferableData
    ) { content -> setContents(content) } != null
  }

  // TODO prefer methods with ranges, because they collect and preprocess for us
//  override fun createClipboardEntry(
//    editor: VimEditor,
//    context: ExecutionContext,
//    text: String,
//    range: TextRange,
//  ): ClipboardEntry {
//    val transferableData = getTransferableData(editor, range, text)
//    val preprocessedText = preprocessText(editor, range, text, transferableData)
//    return IJClipboardEntry(preprocessedText, text, transferableData)
//  }

//  override fun setClipboardText(editor: VimEditor, context: ExecutionContext, entry: ClipboardEntry): Boolean {
//    require(entry is IJClipboardEntry)
//    return setClipboardText(entry.text, entry.rawText, entry.transferableData) != null
//  }

  private fun getTextAndTransferableData(trans: Transferable): Pair<String, List<TextBlockTransferableData>?>? {
    var res: String? = null
    var transferableData: List<TextBlockTransferableData> = ArrayList()
    try {
      val data = trans.getTransferData(DataFlavor.stringFlavor)
      res = data.toString()
      transferableData = collectTransferableData(trans)
    } catch (ignored: HeadlessException) {
    } catch (ignored: UnsupportedFlavorException) {
    } catch (ignored: IOException) {
    }
    if (res == null) return null
    return Pair(res, transferableData)
  }

  @Deprecated("Please use com.maddyhome.idea.vim.api.VimClipboardManager#setClipboardText")
  override fun setClipboardText(text: String, rawText: String, transferableData: List<Any>): Transferable? {
    return handleTextSetting(text, rawText, transferableData) { content -> setContents(content) }
  }

  override fun setPrimaryContent(
    editor: VimEditor,
    context: ExecutionContext,
    textData: VimCopiedText,
    selectionType: SelectionType,
  ): Boolean {
    require(textData is IjVimCopiedText)
    val published = primaryWriter.write(textData.text, textData.transferableData)
    publishedToPrimary.set(if (published) OwnedPrimaryContent(textData, selectionType) else null)
    return published
  }

  override fun getOwnedPrimaryContent(): OwnedPrimaryContent? =
    publishedToPrimary.get()?.takeIf { primaryWriter.ownsSelection() }

  override fun getLastPublishedPrimaryContent(): OwnedPrimaryContent? = publishedToPrimary.get()

  override fun onVisualSelectionChange(editor: VimEditor, caret: ImmutableVimCaret) {
    if (!shouldRepublishVisualSelection(editor)) return
    val text = readVisualSelectionText(editor, caret) ?: return
    val context = injector.executionContextManager.getEditorExecutionContext(editor)
    val selectionType = editor.mode.selectionType ?: SelectionType.CHARACTER_WISE
    setPrimaryContent(editor, context, dumbCopiedText(text), selectionType)
  }

  // vim-engine invokes setVisualSelection transiently from operators (yy, dd, c…), text-object
  // handlers, and put-with-selection too — pushing those would corrupt PRIMARY mid-operation.
  private fun shouldRepublishVisualSelection(editor: VimEditor): Boolean {
    if (!editor.inVisualMode) return false
    if (injector.vimState.executingCommand?.type in OPERATORS_SKIPPING_PRIMARY_PUSH) return false
    return injector.registerGroup.isPrimaryRegisterSupported()
  }

  private fun readVisualSelectionText(editor: VimEditor, caret: ImmutableVimCaret): String? {
    val start = caret.selectionStart
    val end = caret.selectionEnd
    if (start >= end) return null
    val rawText = runCatching { editor.text().subSequence(start, end).toString() }.getOrNull() ?: return null
    if (rawText.isEmpty()) return null
    return ensureLinewiseTrailingNewline(rawText, editor.mode.selectionType)
  }

  // `lineToNativeSelection` ends the selection at the trailing `\n` rather than after it, so the
  // raw substring excludes the newline. Re-add it for line-wise selections so external readers
  // observe linewise content.
  private fun ensureLinewiseTrailingNewline(text: String, selectionType: SelectionType?): String =
    if (selectionType == SelectionType.LINE_WISE && !text.endsWith("\n")) "$text\n" else text

//  override fun setPrimaryText(editor: VimEditor, context: ExecutionContext, entry: ClipboardEntry): Boolean {
//    require(entry is IJClipboardEntry)
//    return setPrimaryText(entry.text, entry.rawText, entry.transferableData) != null
//  }

  override fun collectCopiedText(
    editor: VimEditor,
    context: ExecutionContext,
    range: TextRange,
    text: String,
  ): VimCopiedText {
    val transferableData = getTransferableData(editor, range)
    val preprocessedText = preprocessText(editor, range, text, transferableData)
    return IjVimCopiedText(preprocessedText, transferableData)
  }

  override fun dumbCopiedText(text: String): VimCopiedText {
    return IjVimCopiedText(text, emptyList())
  }

  private fun handleTextSetting(
    text: String,
    rawText: String,
    transferableData: List<Any>,
    setContent: (TextBlockTransferable) -> Unit?,
  ): Transferable? {
    return try {
      val content = buildIjTextTransferable(text, rawText, transferableData)
      setContent(content)
      content
    } catch (_: HeadlessException) {
      null
    }
  }

  override fun getTransferableData(vimEditor: VimEditor, textRange: TextRange): List<TextBlockTransferableData> {
    val editor = vimEditor.ij
    val transferableData: MutableList<TextBlockTransferableData> = ArrayList()
    val project = editor.project ?: return emptyList()

    val file = PsiDocumentManager.getInstance(project).getPsiFile(editor.document) ?: return emptyList()

    // This thing enables alternative context resolve for dumb mode.
    // Please read docs for com.intellij.openapi.project.DumbService.isAlternativeResolveEnabled
    DumbService.getInstance(project).withAlternativeResolveEnabled {
      for (processor in CopyPastePostProcessor.EP_NAME.extensionList) {
        try {
          logger.debug { "Copy paste processor: ${processor.javaClass.name}" }
          transferableData.addAll(
            processor.collectTransferableData(
              file,
              editor,
              textRange.startOffsets,
              textRange.endOffsets,
            ),
          )
        } catch (ignore: IndexNotReadyException) {
        }
      }
    }
    transferableData.add(
      CaretStateTransferableData(
        intArrayOf(0),
        intArrayOf(textRange.endOffset - textRange.startOffset)
      )
    )

    // These data provided by {@link com.intellij.openapi.editor.richcopy.TextWithMarkupProcessor} doesn't work with
    //   IdeaVim and I don't see a way to fix it
    // See https://youtrack.jetbrains.com/issue/VIM-1785
    // See https://youtrack.jetbrains.com/issue/VIM-1731
    transferableData.removeIf { it: TextBlockTransferableData? -> it is RtfTransferableData || it is HtmlTransferableData }
    logger.debug { "Transferable data collected: ${transferableData.joinToString { it.javaClass.name }}" }
    return transferableData
  }

  @Suppress("UNCHECKED_CAST")
  override fun preprocessText(
    vimEditor: VimEditor,
    textRange: TextRange,
    text: String,
    transferableData: List<*>,
  ): String {
    val editor = vimEditor.ij
    val project = editor.project ?: return text
    val file = PsiDocumentManager.getInstance(project).getPsiFile(editor.document) ?: return text
    val rawText = TextBlockTransferable.convertLineSeparators(
      text,
      "\n",
      transferableData as Collection<TextBlockTransferableData?>,
    )
    if (injector.ijOptions(vimEditor).ideacopypreprocess) {
      for (processor in CopyPastePreProcessor.EP_NAME.extensionList) {
        val escapedText = processor.preprocessOnCopy(file, textRange.startOffsets, textRange.endOffsets, rawText)
        if (escapedText != null) {
          return escapedText
        }
      }
    }
    return text
  }

  private fun setContents(contents: Transferable) {
    CopyPasteManagerEx.getInstanceEx().setContents(contents)
  }

  private fun collectTransferableData(transferable: Transferable): List<TextBlockTransferableData> {
    val allValues: MutableList<TextBlockTransferableData> = ArrayList()
    for (processor in CopyPastePostProcessor.EP_NAME.extensionList) {
      val data = processor.extractTransferableData(transferable)
      if (data.isNotEmpty()) {
        allValues.addAll(data)
      }
    }
    return allValues
  }

  private fun getContents(): Transferable? = CopyPasteManagerEx.getInstanceEx().contents

  companion object {
    val logger = vimLogger<IjClipboardManager>()

    private val OPERATORS_SKIPPING_PRIMARY_PUSH = setOf(
      Command.Type.COPY,
      Command.Type.DELETE,
      Command.Type.CHANGE,
      Command.Type.PASTE,
      Command.Type.INSERT,
    )
  }
}

data class IjVimCopiedText(override val text: String, val transferableData: List<Any>) : VimCopiedText {
  override fun updateText(newText: String): VimCopiedText = IjVimCopiedText(newText, transferableData)
}

/**
 * Builds the `TextBlockTransferable` for clipboard and PRIMARY writes. We pin a single-range
 * `CaretStateTransferableData` so IntelliJ doesn't reshape the pasted text to match whatever
 * multi-caret arrangement the destination editor has.
 *
 * Throws [HeadlessException] on a headless JVM; callers handle.
 */
@Suppress("UNCHECKED_CAST")
internal fun buildIjTextTransferable(
  text: String,
  rawText: String,
  transferableData: List<Any>,
): TextBlockTransferable {
  val mutableData = (transferableData as List<TextBlockTransferableData>).toMutableList()
  val normalized = TextBlockTransferable.convertLineSeparators(text, "\n", mutableData)
  if (mutableData.none { it is CaretStateTransferableData }) {
    mutableData += CaretStateTransferableData(intArrayOf(0), intArrayOf(normalized.length))
  }
  return TextBlockTransferable(normalized, mutableData, RawText(rawText))
}
