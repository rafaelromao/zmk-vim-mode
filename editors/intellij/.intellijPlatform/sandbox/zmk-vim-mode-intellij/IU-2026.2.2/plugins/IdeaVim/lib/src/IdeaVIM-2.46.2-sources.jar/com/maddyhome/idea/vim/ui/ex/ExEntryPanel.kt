/*
 * Copyright 2003-2026 The IdeaVim authors
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE.txt file or at
 * https://opensource.org/licenses/MIT.
 */
package com.maddyhome.idea.vim.ui.ex

import com.intellij.ide.ui.LafManager
import com.intellij.ide.ui.LafManagerListener
import com.intellij.openapi.actionSystem.DataContext
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.editor.Editor
import com.intellij.openapi.editor.colors.EditorColors
import com.intellij.openapi.editor.colors.EditorColorsListener
import com.intellij.openapi.editor.colors.EditorColorsScheme
import com.intellij.openapi.wm.IdeFocusManager
import com.intellij.ui.DocumentAdapter
import com.intellij.util.IJSwingUtilities
import com.maddyhome.idea.vim.EventFacade
import com.maddyhome.idea.vim.KeyHandler.Companion.getInstance
import com.maddyhome.idea.vim.VimPlugin
import com.maddyhome.idea.vim.action.VimShortcutKeyAction
import com.maddyhome.idea.vim.api.CommandLineCompletion
import com.maddyhome.idea.vim.api.ExecutionContext
import com.maddyhome.idea.vim.api.VimCommandLine
import com.maddyhome.idea.vim.api.VimCommandLineCaret
import com.maddyhome.idea.vim.api.VimEditor
import com.maddyhome.idea.vim.api.VimKeyGroupBase
import com.maddyhome.idea.vim.api.VimSearchGroupBase
import com.maddyhome.idea.vim.api.VirtualBufferKind
import com.maddyhome.idea.vim.api.globalOptions
import com.maddyhome.idea.vim.api.injector
import com.maddyhome.idea.vim.ex.ranges.LineRange
import com.maddyhome.idea.vim.helper.ShortcutHelper
import com.maddyhome.idea.vim.helper.exitVisualMode
import com.maddyhome.idea.vim.helper.requestFocus
import com.maddyhome.idea.vim.helper.selectEditorFont
import com.maddyhome.idea.vim.helper.shouldIgnoreCase
import com.maddyhome.idea.vim.helper.updateIncsearchHighlights
import com.maddyhome.idea.vim.key.interceptors.VimInputInterceptor
import com.maddyhome.idea.vim.newapi.IjVimCaret
import com.maddyhome.idea.vim.newapi.IjVimEditor
import com.maddyhome.idea.vim.ui.ExPanelBorder
import com.maddyhome.idea.vim.vimscript.model.commands.Command
import com.maddyhome.idea.vim.vimscript.model.commands.GlobalCommand
import com.maddyhome.idea.vim.vimscript.model.commands.SubstituteCommand
import com.maddyhome.idea.vim.vimscript.parser.VimscriptParser
import org.jetbrains.annotations.Contract
import org.jetbrains.annotations.TestOnly
import org.jetbrains.annotations.VisibleForTesting
import java.awt.Color
import java.awt.GridBagConstraints
import java.awt.GridBagLayout
import java.lang.ref.WeakReference
import javax.swing.JComponent
import javax.swing.JLabel
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.KeyStroke
import javax.swing.SwingUtilities
import javax.swing.event.DocumentEvent
import javax.swing.event.DocumentListener
import javax.swing.text.GlyphView
import javax.swing.text.View
import kotlin.math.max
import kotlin.math.min

/**
 * This is used to enter ex commands such as searches and "colon" commands
 */
class ExEntryPanel private constructor() : JPanel(), VimCommandLine {
  private var weakEditor: WeakReference<Editor?>? = null

  private val glassPaneManager = object : GlassPaneManager() {
    override fun onResize() = positionPanel()
  }

  override var isReplaceMode: Boolean = false
  override var inputProcessing: ((String) -> Unit)? = null
  override var finishOn: Char? = null
  override var lastEntry: String? = null
  override var activeCompletion: CommandLineCompletion? = null

  override var isAbbreviationInvalidated: Boolean = false
  private var lastSeenCmdlineLength: Int = 0

  /** Called from [ExTextField]'s caret listener whenever the cmdline caret moves. */
  internal fun noteCmdlineCaretMove(currentLength: Int) {
    if (currentLength == lastSeenCmdlineLength) {
      isAbbreviationInvalidated = true
    }
    lastSeenCmdlineLength = currentLength
  }

  var inputInterceptor: VimInputInterceptor? = null
  var context: DataContext? = null

  override fun isExCommand(): Boolean {
    return getLabel().startsWith(":")
  }

  override fun getIncsearchMatchOffset(): Int {
    return incsearchMatchOffset
  }

  override fun showCompletionBar(completion: CommandLineCompletion) {
    if (ApplicationManager.getApplication().isUnitTestMode) return
    val editor = this.ijEditor ?: return

    completionPanel.updateColors(editor.colorsScheme.defaultForeground, entry.getBackground())
    completionPanel.updateFont(entry.getFont())
    completionPanel.setItems(completion.displayNames, completion.currentIndex)

    if (!isCompletionBarVisible) {
      glassPaneManager.glassPane?.add(completionPanel)
      isCompletionBarVisible = true
    }
    positionCompletionPanel()
  }

  override fun selectCompletionItem(selectedIndex: Int?) {
    if (!isCompletionBarVisible || selectedIndex == null) return
    completionPanel.setSelectedIndex(selectedIndex)
  }

  override fun hideCompletionBar() {
    if (!isCompletionBarVisible) return
    isCompletionBarVisible = false
    glassPaneManager.glassPane?.let {
      it.remove(completionPanel)
      it.repaint()
    }
  }

  private fun dismissCompletionIfTextChanged() {
    val completion = activeCompletion ?: return
    if (text != completion.expectedText) {
      activeCompletion = null
      hideCompletionBar()
    }
  }

  val ijEditor: Editor?
    get() = if (weakEditor != null) weakEditor!!.get() else null

  override val editor: VimEditor
    get() {
      val editor = this.ijEditor ?: throw RuntimeException("Editor was disposed for active command line")
      return IjVimEditor(editor)
    }

  fun setEditor(editor: Editor?) {
    weakEditor = if (editor == null) {
      null
    } else {
      WeakReference<Editor?>(editor)
    }
  }

  /**
   * Turns on the ex entry field for the given editor
   *
   * @param editor   The editor to use for display
   * @param context  The data context
   * @param label    The label for the ex entry (i.e. :, /, or ?)
   * @param initText The initial text for the entry
   */
  fun activate(editor: Editor, context: DataContext?, label: String, initText: String) {
    logger.info("Activate ex entry panel")
    this.myLabel.setText(label)
    this.myLabel.setFont(selectEditorFont(editor, label))
    entry.reset()
    entry.setText(initText)
    entry.setFont(selectEditorFont(editor, initText))
    parent = editor.contentComponent

    applyColorScheme(editor)

    this.context = context
    setEditor(editor)

    // This is a singleton panel reused across activations. Drop any inccommand preview state left over from a previous
    // activation that was abandoned without a clean deactivate (e.g. the editor was disposed).
    inccommandPreview.reset()

    entry.document.addDocumentListener(fontListener)
    // The listener drives both incsearch highlighting and the inccommand preview, so attach it if either is enabled.
    if (this.isIncSearchEnabled || this.isIncCommandEnabled) {
      entry.document.addDocumentListener(incrementalCommandLineListener)
      caretOffset = editor.caretModel.offset
      verticalOffset = editor.scrollingModel.verticalScrollOffset
      horizontalOffset = editor.scrollingModel.horizontalScrollOffset
      incsearchMatchOffset = 0
    }

    if (!ApplicationManager.getApplication().isUnitTestMode) {
      glassPaneManager.activate(editor, this)
      positionPanel()
      glassPaneManager.show()
      SwingUtilities.invokeLater { entry.requestFocusInWindow() }
    }
    isActive = true
    // Must run last: entry.setText()/entry.reset() above fire the caret listener, which would
    // otherwise spuriously flip isAbbreviationInvalidated to true before the user has typed.
    resetAbbreviationTracking()
  }

  private fun resetAbbreviationTracking() {
    lastSeenCmdlineLength = entry.text.length
    isAbbreviationInvalidated = false
  }

  fun deactivate(refocusOwningEditor: Boolean) {
    deactivate(refocusOwningEditor, true)
  }

  /**
   * Turns off the ex entry field and optionally puts the focus back to the original component
   */
  override fun deactivate(refocusOwningEditor: Boolean, resetCaret: Boolean) {
    logger.info("Deactivate ex entry panel")
    if (!this.isActive) return

    clearPromptCharacter()
    hideCompletionBar()
    activeCompletion = null
    try {
      entry.document.removeDocumentListener(fontListener)

      // Revert any inccommand preview before anything else. On <CR> the command line is closed (and thus deactivated)
      // *before* the real command executes (see CommandKeyConsumer), so reverting here guarantees the real substitution
      // runs against the original, un-previewed document - and on <Esc> it simply restores the buffer.
      val previewEditor = this.ijEditor
      if (previewEditor != null && !previewEditor.isDisposed) {
        inccommandPreview.clear(previewEditor)
      }

      // incsearch/inccommand won't change in the lifetime of this activation
      if (this.isIncSearchEnabled || this.isIncCommandEnabled) {
        entry.document.removeDocumentListener(incrementalCommandLineListener)
      }
      if (this.isIncSearchEnabled) {
        // TODO: Reduce the amount of unnecessary work here
        // If incsearch and hlsearch are enabled, and if this is a search panel, we'll have all of the results correctly
        // highlighted. But because we don't know why we're being closed, and what handler is being called next, we need
        // to reset state. This will remove all highlights and reset back to the last accepted search results. This is
        // fine for <Esc>. But if we hit <Enter>, the search handler will remove the highlights again, perform the same
        // search that we did for incsearch and add highlights back. The `:nohlsearch` command, even if bound to a
        // shortcut, is still processed by the ex entry panel, so deactivating will force update remove, search and add
        // of the current search results before the `NoHLSearchHandler` will remove all highlights again
        val editor = this.ijEditor
        if (editor != null && !editor.isDisposed && resetCaret) {
          resetCaret(editor)
        }

        (VimPlugin.getSearch() as VimSearchGroupBase).resetIncsearchHighlights()
      }

      entry.deactivate()
    } finally {
      // Make sure we hide the UI, especially if something goes wrong
      if (!ApplicationManager.getApplication().isUnitTestMode) {
        if (refocusOwningEditor && parent != null) {
          requestFocus(parent!!)
        }

        glassPaneManager.deactivate()
      }

      parent = null
    }

    isReplaceMode = false
    setEditor(null)
    context = null

    // We have this in the end, because `entry.deactivate()` communicates with active panel during deactivation
    this.isActive = false
    finishOn = null
    this.inputInterceptor = null
    inputProcessing = null
  }

  private fun reset() {
    deactivate(false)
  }

  private fun resetCaretOffsetAndScroll(editor: Editor) {
    // Reset the original caret, with original scroll offsets
    resetCaret(editor)
    resetScroll(editor)
  }

  private fun resetCaret(editor: Editor) {
    val primaryCaret = editor.caretModel.primaryCaret
    if (primaryCaret.offset != caretOffset) {
      primaryCaret.moveToOffset(caretOffset)
    }
  }

  private fun resetScroll(editor: Editor) {
    val scrollingModel = editor.scrollingModel
    if (scrollingModel.horizontalScrollOffset != horizontalOffset ||
      scrollingModel.verticalScrollOffset != verticalOffset
    ) {
      scrollingModel.scroll(horizontalOffset, verticalOffset)
    }
  }

  private val fontListener: DocumentListener = object : DocumentAdapter() {
    override fun textChanged(e: DocumentEvent) {
      val text = entry.getText()
      val newFont = selectEditorFont(ijEditor, text)
      if (newFont !== entry.getFont()) {
        entry.setFont(newFont)
      }
    }
  }


  // Fires on every command-line edit to update the incremental UI: incsearch highlighting (when 'incsearch' is set) and
  // the inccommand substitute preview (when 'inccommand' is set). Named generically as it covers more than search.
  private val incrementalCommandLineListener: DocumentListener = object : DocumentAdapter() {
    override fun textChanged(e: DocumentEvent) {
      val editor = ijEditor ?: return
      // Editing the pattern restarts incsearch from the first match, cancelling any `c_CTRL-G` advancement.
      incsearchMatchOffset = 0
      try {
        when (val update = parseCommandLineForPreview(editor)) {
          is CommandLineUpdate.Renderable -> {
            if (isIncSearchEnabled) showIncsearchHighlights(editor, update)
            updateInccommandPreview(editor, update)
          }

          CommandLineUpdate.ClearPreview -> inccommandPreview.clearBufferPreview(editor)

          CommandLineUpdate.ResetIncsearch -> {
            inccommandPreview.clearBufferPreview(editor)
            if (isIncSearchEnabled) {
              (VimPlugin.getSearch() as VimSearchGroupBase).resetIncsearchHighlights()
              resetCaretOffsetAndScroll(editor)
            }
          }
        }
      } catch (ex: Throwable) {
        // Make sure the exception doesn't leak out of the handler, because it can break the text entry field and
        // require the editor to be closed/reopened. The worst that will happen is no incsearch highlights or preview.
        logger.error("Error while updating the incremental command-line UI", ex)
      }
    }
  }

  /** What the current command-line text means for the incremental UI (highlighting and/or substitute preview). */
  private sealed interface CommandLineUpdate {
    /** A renderable search (`/`, `?`) or ex command (`:s`, `:g`) with a usable pattern. */
    class Renderable(
      val labelText: String,
      val separator: Char,
      val searchText: String,
      val isExCommand: Boolean,
      val searchRange: LineRange?,
      val substituteCommand: SubstituteCommand?,
    ) : CommandLineUpdate

    /** Nothing to render - an empty or non-previewable command line. */
    object ClearPreview : CommandLineUpdate

    /** An in-progress ex command that lost its pattern/range; restore the previous incsearch highlights. */
    object ResetIncsearch : CommandLineUpdate
  }

  private fun parseCommandLineForPreview(editor: Editor): CommandLineUpdate {
    val labelText = myLabel.text // Either '/', '?' or ':'
    if (labelText != ":") {
      // A search: '/' (forwards) or '?' (backwards). The whole entry is the pattern.
      return CommandLineUpdate.Renderable(labelText, labelText[0], text, isExCommand = false, null, null)
    }

    if (text.isEmpty()) return CommandLineUpdate.ClearPreview
    val command = getIncsearchCommand(text) ?: return CommandLineUpdate.ClearPreview

    // The argument is e.g. `/foo/bar/g` for `:%s/foo/bar/g`: the first char is the separator, the rest is the pattern
    // (plus replacement and flags). `%` is the range, `s` the command, `/` the argument separator.
    val argument = command.commandArgument
    var separator = labelText[0]
    var searchText = ""
    if (argument.length > 1) {
      separator = argument[0]
      searchText = argument.substring(1)
    }
    val searchRange = if (searchText.isNotEmpty()) command.getLineRangeSafe(IjVimEditor(editor)) else null
    if (searchText.isEmpty() || searchRange == null) {
      // E.g. highlight `whatever`, type `:%s/foo` (now highlighting `foo`), then delete back to `:%s/`: restore
      // `whatever`. A null range means the user typed an invalid range (e.g. an unset mark).
      return CommandLineUpdate.ResetIncsearch
    }
    return CommandLineUpdate.Renderable(
      labelText, separator, searchText, isExCommand = true, searchRange, command as? SubstituteCommand
    )
  }

  private fun showIncsearchHighlights(editor: Editor, update: CommandLineUpdate.Renderable) {
    // Get a snapshot of the count for the in-progress command and coerce it to 1. This value will include all count
    // components - selecting register(s), operator and motions. E.g. `2"a3"b4"c5d6/` will return 720. If we're showing
    // highlights for an Ex command like `:s`, the command builder will be empty, but we'll still get a valid value.
    // Include any `c_CTRL-G`/`c_CTRL-T` advancement so the current match moves as the user presses <C-G>/<C-T>.
    val forwards = update.labelText != "?" // :s, :g, :v are treated as forwards
    val patternEnd = injector.searchGroup.findEndOfPattern(update.searchText, update.separator, 0)
    val pattern = update.searchText.take(patternEnd)
    val count1 = normalizeIncsearchCount(
      editor,
      pattern,
      max(1, getInstance().keyHandlerState.editorCommandBuilder.calculateCount0Snapshot()) + incsearchMatchOffset,
      update.searchRange,
    )
    if (count1 == null) {
      resetCaretOffsetAndScroll(editor)
      return
    }

    injector.editorGroup.closeEditorSearchSession(IjVimEditor(editor))
    // A substitute/global command highlights every match in its range, even without 'hlsearch'.
    val matchOffset = updateIncsearchHighlights(
      editor, pattern, count1, forwards, caretOffset, update.searchRange, forceShowAllMatches = update.isExCommand
    )
    if (matchOffset == -1) {
      resetCaretOffsetAndScroll(editor)
      return
    }

    // Moving the caret will update the Visual selection, which is only valid while performing a search. We want to
    // remove the Visual selection when the incsearch is for a command, as this is always unrelated to the current
    // selection. E.g. `V/foo` should update the selection to the search result, but `V` followed by `:<C-U>%s/foo`
    // should remove the selection first. We're in Command-line with Visual pending; exiting Visual leaves Command-line.
    if (update.isExCommand) IjVimEditor(editor).exitVisualMode()
    IjVimCaret(editor.caretModel.primaryCaret).moveToOffset(matchOffset)
  }

  /**
   * `c_CTRL-G` / `c_CTRL-T` - move the incsearch preview to the next ([next] == true) or previous ([next] == false)
   * match, without closing the command line or running the search.
   *
   * Steps the match offset and re-renders the current pattern. Does nothing if 'incsearch' is off or there's no usable
   * pattern (e.g. an empty command line).
   */
  override fun advanceIncsearchMatch(next: Boolean) {
    if (!isIncSearchEnabled) return
    val editor = ijEditor ?: return
    val update = parseCommandLineForPreview(editor) as? CommandLineUpdate.Renderable ?: return
    incsearchMatchOffset += if (next) 1 else -1
    showIncsearchHighlights(editor, update)
  }

  /**
   * Coerce the incsearch match count into the valid `[1, matchCount]` range, wrapping around like 'wrapscan'.
   *
   * `c_CTRL-T` can step [count1] below 1 (before the first match); wrap it to the last match. Only recomputes the total
   * match count when needed (i.e. the fast path of typing a pattern, where the count is already >= 1, is untouched).
   * Returns null when the pattern has no matches, so the caller can reset the caret.
   */
  private fun normalizeIncsearchCount(editor: Editor, pattern: String, count1: Int, searchRange: LineRange?): Int? {
    if (count1 >= 1) return count1
    val startLine = searchRange?.startLine ?: 0
    val endLine = searchRange?.endLine ?: -1
    val ignoreCase = shouldIgnoreCase(pattern, false)
    val total = injector.searchHelper.findAll(IjVimEditor(editor), pattern, startLine, endLine, ignoreCase).size
    if (total == 0) return null
    return Math.floorMod(count1 - 1, total) + 1
  }

  /** Render the inccommand preview. Called after highlighting, which must see the original (un-previewed) text. */
  private fun updateInccommandPreview(editor: Editor, update: CommandLineUpdate.Renderable) {
    val command = update.substituteCommand
    // Only preview once a replacement delimiter has been typed (e.g. `:%s/foo/` rather than just `:%s/foo`).
    if (isIncCommandEnabled && command != null && update.searchRange != null && update.searchText.contains("/")) {
      val splitContent = inccommandPreview.apply(editor, command, update.searchRange)
      updateSplitPreviewWindow(editor, splitContent)
    } else {
      inccommandPreview.clearBufferPreview(editor)
    }
  }

  private fun updateSplitPreviewWindow(editor: Editor, content: String?) {
    if (injector.globalOptions().inccommand != "split" || content == null) return
    val vimEditor = IjVimEditor(editor)
    val context = injector.executionContextManager.getEditorExecutionContext(vimEditor)
    openSubstitutePreview(context, content, vimEditor)
  }

  private fun openSubstitutePreview(
    context: ExecutionContext,
    content: String,
    vimEditor: IjVimEditor,
  ) {
    ApplicationManager.getApplication().invokeLater {
      val virtualBufferGroup = injector.virtualBufferGroup
      if (virtualBufferGroup.isOpen(context, VirtualBufferKind.SubstitutePreview)) {
        virtualBufferGroup.refresh(context, VirtualBufferKind.SubstitutePreview, content)
        return@invokeLater
      }
      virtualBufferGroup.open(
        context,
        vimEditor,
        VirtualBufferKind.SubstitutePreview,
        content,
        focus = false,
      )
    }
  }

  @Contract("null -> null")
  private fun getIncsearchCommand(commandText: String?): Command? {
    if (commandText == null) return null
    try {
      val exCommand = VimscriptParser.parseCommand(commandText)
      // TODO: Add smagic and snomagic here if/when the commands are supported
      if (exCommand is SubstituteCommand || exCommand is GlobalCommand) {
        return exCommand
      }
    } catch (e: Exception) {
      logger.error("Cannot parse command for incsearch", e)
    }
    return null
  }

  /**
   * Gets the label for the ex entry. This should be one of ":", "/", or "?"
   *
   * @return The ex entry label
   */
  override fun getLabel(): String {
    return myLabel.text
  }

  override fun toggleReplaceMode() {
    entry.toggleInsertReplace()
  }

  override val text: String
    get() = entry.getText()

  override val modelessSelection: String
    get() = entry.selectedText ?: ""

  @TestOnly
  fun setModelessSelection(start: Int, end: Int) {
    entry.select(start, end)
  }

  override fun getRenderedText() = buildString {
    getRenderedText(entry.getUI().getRootView(entry))
    if (last() == '\n') {
      deleteCharAt(lastIndex)
    }
  }

  private fun StringBuilder.getRenderedText(view: View) {
    if (view.element.isLeaf) {
      if (view is GlyphView) {
        val text = view.getText(view.getStartOffset(), view.getEndOffset())
        append(text)

        // GlyphView doesn't render a trailing new line, but uses it to flush the characters in the preceding string
        // Typically, we won't get a newline in the middle of a string, but we do add the prompt to the end of the doc
        if (last() == '\n') {
          deleteCharAt(lastIndex)
        }
      } else {
        append("<Unknown leaf view. Expected GlyphView, got: ")
        append(view.javaClass.getName())
        append(">")
      }
    } else {
      val viewCount = view.viewCount
      for (i in 0..<viewCount) {
        val child = view.getView(i)
        getRenderedText(child)
      }
    }
  }

  override fun setPromptCharacter(promptCharacter: Char) {
    val entryUi = entry.getUI()
    if (entryUi is ExTextFieldUI) {
      entryUi.setPromptCharacter(promptCharacter)
    }
  }

  override fun clearPromptCharacter() {
    val exTextFieldUI = entry.getUI()
    if (exTextFieldUI is ExTextFieldUI) {
      exTextFieldUI.clearPromptCharacter()
    }
  }

  /**
   * Pass the keystroke on to the text field for handling
   *
   *
   * The text field for the command line will forward a pressed or typed keystroke to the key handler, which will either
   * consume it for mapping or a command. If it's not consumed or if it's mapped, the keystroke is returned to the
   * command line to complete handling. This includes typed characters as well as pressed shortcuts.
   *
   *
   * @param key The potentially mapped keystroke
   */
  override fun handleKey(key: KeyStroke) {
    entry.handleKey(key)
    val myInputProcessor = inputProcessing
    if (finishOn != null && key.keyChar == finishOn && myInputProcessor != null) {
      val myText = text
      close(refocusOwningEditor = true, resetCaret = true)
      myInputProcessor.invoke(myText)
    }
  }

  // Called automatically when the LAF is changed and the component is visible, and manually by the LAF listener handler
  override fun updateUI() {
    super.updateUI()

    setBorder(ExPanelBorder())

    // Swing uses a bad pattern of calling updateUI() from the constructor. At this moment, `entry` and myLabel are null.
    @Suppress("SENSELESS_COMPARISON")
    if (entry != null && myLabel != null) {
      setFontForElements()

      // Label background is automatically picked up
      myLabel.setForeground(entry.getForeground())

      // Make sure the panel is positioned correctly if we're changing font size
      positionPanel()
    }
  }

  /**
   * Apply the colours that depend on the editor colour scheme.
   */
  private fun applyColorScheme(editor: Editor) {
    val foregroundColour = editor.colorsScheme.defaultForeground
    entry.setForeground(foregroundColour)
    // TODO: Introduce IdeaVim colour scheme for "SpecialKey"?
    val whitespaceColour = editor.colorsScheme.getColor(EditorColors.WHITESPACES_COLOR)
    entry.setSpecialKeyForeground(whitespaceColour ?: foregroundColour)
    this.myLabel.setForeground(entry.getForeground())
  }

  /**
   * Refresh the typed text colour when the editor colour scheme changes while the command line is open.
   *
   * See [applyColorScheme] for why a LAF refresh alone doesn't update the entry's foreground.
   */
  internal fun refreshColors() {
    val editor = ijEditor ?: return
    @Suppress("SENSELESS_COMPARISON")
    if (entry == null) return
    applyColorScheme(editor)
  }

  override fun getForeground(): Color? {
    @Suppress("SENSELESS_COMPARISON")
    if (entry == null) {
      // Swing uses a bad pattern of calling getForeground() from the constructor. At this moment, `entry` is null.
      return super.getForeground()
    }
    return entry.getForeground()
  }

  override fun getBackground(): Color? {
    @Suppress("SENSELESS_COMPARISON")
    if (entry == null) {
      // Swing uses a bad pattern of calling getBackground() from the constructor. At this moment, `entry` is null.
      return super.getBackground()
    }
    return entry.getBackground()
  }

  private fun setFontForElements() {
    myLabel.setFont(selectEditorFont(this.ijEditor, myLabel.text))
    entry.setFont(selectEditorFont(this.ijEditor, entry.getText()))
  }

  private fun positionPanel() {
    if (parent == null) return

    val scroll = SwingUtilities.getAncestorOfClass(JScrollPane::class.java, parent)
    val height = getPreferredSize().getHeight().toInt()
    if (scroll != null) {
      val bounds = scroll.bounds
      bounds.translate(0, scroll.getHeight() - height)
      bounds.height = height
      val pos = SwingUtilities.convertPoint(scroll.getParent(), bounds.location, glassPaneManager.glassPane)
      bounds.location = pos
      setBounds(bounds)
      repaint()
    }

    if (isCompletionBarVisible) {
      positionCompletionPanel()
    }
  }

  private fun positionCompletionPanel() {
    val myBounds = bounds
    if (myBounds.width == 0) return

    val completionHeight = completionPanel.preferredSize.height
    completionPanel.setBounds(
      myBounds.x,
      myBounds.y - completionHeight,
      myBounds.width,
      completionHeight,
    )
    completionPanel.revalidate()
    completionPanel.repaint()
  }

  private val isIncSearchEnabled: Boolean
    get() = injector.globalOptions().incsearch

  // 'inccommand' is a string option: "" (off), "nosplit" or "split". We currently render both non-empty values as an
  // in-buffer preview (the "split" preview window is not yet implemented).
  private val isIncCommandEnabled: Boolean
    get() = injector.globalOptions().inccommand.isNotEmpty()

  /**
   * Checks if the ex entry panel is currently active
   *
   * @return true if active, false if not
   */
  var isActive: Boolean = false
    private set

  // UI stuff
  @VisibleForTesting
  val entry: ExTextField = ExTextField(this)

  private var parent: JComponent? = null
  private val myLabel: JLabel = JLabel(" ")
  private val completionPanel = ExCompletionPanel()
  private var isCompletionBarVisible = false

  // incsearch stuff
  private var verticalOffset = 0
  private var horizontalOffset = 0
  private var caretOffset = 0

  // How many matches past the first `c_CTRL-G` has advanced the incsearch preview. Added to the command count so the
  // "current match" moves forward as the user presses <C-G>. Reset when the panel is (re)activated or the pattern edited.
  private var incsearchMatchOffset = 0

  // Renders the 'inccommand' preview (live :substitute) into the buffer as the command line is edited.
  private val inccommandPreview = InccommandPreview()

  init {

    val layout = GridBagLayout()
    val gbc = GridBagConstraints()

    setLayout(layout)
    gbc.gridx = 0
    layout.setConstraints(this.myLabel, gbc)
    add(this.myLabel)
    gbc.gridx = 1
    gbc.weightx = 1.0
    gbc.fill = GridBagConstraints.HORIZONTAL
    layout.setConstraints(entry, gbc)
    add(entry)

    // This does not need to be unregistered, it's registered as a custom UI property on this
    EventFacade.getInstance().registerCustomShortcutSet(
      VimShortcutKeyAction.instance, ShortcutHelper.toShortcutSet(
        (injector.keyGroup as VimKeyGroupBase).requiredShortcutKeys
      ), entry
    )

    updateUI()
  }

  override val caret: VimCommandLineCaret
    get() = entry.caret as VimCommandLineCaret

  override fun setText(string: String, updateLastEntry: Boolean) {
    // It's a feature of Swing that the caret is moved when we set a new text. However, our API is Swing independent,
    // and we do not expect this
    val offset = caret.offset
    entry.updateText(string)
    if (updateLastEntry) entry.saveLastEntry()
    caret.offset = min(offset, text.length)

    dismissCompletionIfTextChanged()
  }

  override fun deleteText(offset: Int, length: Int) {
    entry.deleteText(offset, length)
    dismissCompletionIfTextChanged()
  }

  override fun insertText(offset: Int, string: String) {
    // Remember that replace mode is different to overwrite! The document handles overwrite, but we must handle replace
    if (isReplaceMode) {
      entry.deleteText(offset, string.length)
    }
    entry.insertText(offset, string)
    dismissCompletionIfTextChanged()
  }

  override fun clearCurrentAction() {
    entry.clearCurrentAction()
  }

  override fun focus() {
    IdeFocusManager.findInstance().requestFocus(entry, true)
  }

  class LafListener : LafManagerListener {
    override fun lookAndFeelChanged(source: LafManager) {
      if (VimPlugin.isNotEnabled()) return

      // Calls updateUI on this and child components
      if (instance != null) {
        IJSwingUtilities.updateComponentTreeUI(instance)
      }
    }
  }

  /**
   * Refresh the typed text colour when the editor colour scheme changes.
   *
   * The scheme changes both when it's switched directly and when an IDE theme switch swaps in a different bundled
   * scheme. Unlike [LafListener]'s `updateComponentTreeUI`, this re-applies the foreground of the (explicitly coloured)
   * entry field. See [applyColorScheme].
   */
  class ColorSchemeListener : EditorColorsListener {
    override fun globalSchemeChange(scheme: EditorColorsScheme?) {
      if (VimPlugin.isNotEnabled()) return
      instance?.refreshColors()
    }
  }

  companion object {
    var instance: ExEntryPanel? = null

    fun getOrCreatePanelInstance(): ExEntryPanel {
      return instance ?: let {
        val exEntryPanel = ExEntryPanel()
        instance = exEntryPanel
        exEntryPanel
      }
    }

    fun fullReset() {
      val myInstance = instance
      if (myInstance != null) {
        myInstance.reset()
        instance = null
      }
    }

    private val logger = Logger.getInstance(ExEntryPanel::class.java.getName())
  }
}
